/* ============================================================
   INSTAGRAM USER ENGAGEMENT ANALYSIS — ALL SQL QUERIES
   Prepared by: Shushan Kumar
   Database: ig_clone
   ============================================================ */


/* ============================================================
   OBJECTIVE QUESTIONS
   ============================================================ */

/* -----------------------------------------------------------
   Q1. Are there any tables with duplicate or missing/null
       values? If so, how would you handle them?
   ----------------------------------------------------------- */

-- 1a. Check every "should never be null" column across the schema
SELECT 'users.username'         AS column_checked, COUNT(*) AS null_count FROM users    WHERE username IS NULL
UNION ALL
SELECT 'photos.image_url',      COUNT(*) FROM photos   WHERE image_url IS NULL
UNION ALL
SELECT 'photos.user_id',        COUNT(*) FROM photos   WHERE user_id IS NULL
UNION ALL
SELECT 'comments.comment_text', COUNT(*) FROM comments WHERE comment_text IS NULL
UNION ALL
SELECT 'comments.user_id',      COUNT(*) FROM comments WHERE user_id IS NULL
UNION ALL
SELECT 'comments.photo_id',     COUNT(*) FROM comments WHERE photo_id IS NULL
UNION ALL
SELECT 'likes.user_id',         COUNT(*) FROM likes    WHERE user_id IS NULL
UNION ALL
SELECT 'likes.photo_id',        COUNT(*) FROM likes    WHERE photo_id IS NULL
UNION ALL
SELECT 'follows.follower_id',   COUNT(*) FROM follows  WHERE follower_id IS NULL
UNION ALL
SELECT 'follows.followee_id',   COUNT(*) FROM follows  WHERE followee_id IS NULL
UNION ALL
SELECT 'tags.tag_name',         COUNT(*) FROM tags     WHERE tag_name IS NULL
UNION ALL
SELECT 'photo_tags.photo_id',   COUNT(*) FROM photo_tags WHERE photo_id IS NULL
UNION ALL
SELECT 'photo_tags.tag_id',     COUNT(*) FROM photo_tags WHERE tag_id IS NULL;

-- 1b. Check for duplicate usernames (no UNIQUE constraint on this column)
SELECT username, COUNT(*) AS cnt
FROM users
GROUP BY username
HAVING COUNT(*) > 1;

-- 1c. Check for duplicate image_urls (no UNIQUE constraint on this column)
SELECT image_url, COUNT(*) AS cnt
FROM photos
GROUP BY image_url
HAVING COUNT(*) > 1;

-- 1d. Check for duplicate comments (same user, same photo, same text)
SELECT user_id, photo_id, comment_text, COUNT(*) AS cnt
FROM comments
GROUP BY user_id, photo_id, comment_text
HAVING COUNT(*) > 1;

-- 1e. How to remove duplicates if found (keep the earliest row only)
WITH ranked AS (
  SELECT id,
         ROW_NUMBER() OVER (PARTITION BY user_id, photo_id, comment_text ORDER BY id) AS rn
  FROM comments
)
DELETE FROM comments
WHERE id IN (SELECT id FROM ranked WHERE rn > 1);

-- 1f. Prevent recurrence going forward
ALTER TABLE users  ADD CONSTRAINT uq_username  UNIQUE (username);
ALTER TABLE photos ADD CONSTRAINT uq_image_url UNIQUE (image_url);


/* -----------------------------------------------------------
   Q2. What is the distribution of user activity levels
       (posts, likes, comments) across the user base?
   ----------------------------------------------------------- */

SELECT
    activity_tier,
    COUNT(*) AS num_users
FROM (
    SELECT
        u.id,
        CASE
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) = 0
                THEN 'Inactive (0)'
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) BETWEEN 1 AND 20
                THEN 'Low (1-20)'
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) BETWEEN 21 AND 100
                THEN 'Medium (21-100)'
            ELSE 'High (100+)'
        END AS activity_tier
    FROM users u
    LEFT JOIN (SELECT user_id, COUNT(*) AS posts_count    FROM photos   GROUP BY user_id) p ON p.user_id = u.id
    LEFT JOIN (SELECT user_id, COUNT(*) AS likes_count    FROM likes    GROUP BY user_id) l ON l.user_id = u.id
    LEFT JOIN (SELECT user_id, COUNT(*) AS comments_count FROM comments GROUP BY user_id) c ON c.user_id = u.id
) sub
GROUP BY activity_tier
ORDER BY num_users DESC;


/* -----------------------------------------------------------
   Q3. Calculate the average number of tags per post
       (photo_tags and photos tables)
   ----------------------------------------------------------- */

SELECT
    ROUND(COUNT(pt.tag_id) * 1.0 / COUNT(DISTINCT p.id), 2) AS avg_tags_per_post
FROM photos p
LEFT JOIN photo_tags pt ON pt.photo_id = p.id;


/* -----------------------------------------------------------
   Q4. Identify the top users with the highest engagement
       rates (likes, comments) on their posts and rank them.
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COALESCE(l.total_likes, 0) AS total_likes_received,
    COALESCE(c.total_comments, 0) AS total_comments_received,
    COALESCE(l.total_likes, 0) + COALESCE(c.total_comments, 0) AS total_engagement,
    RANK() OVER (ORDER BY COALESCE(l.total_likes, 0) + COALESCE(c.total_comments, 0) DESC) AS engagement_rank
FROM users u
LEFT JOIN (
    SELECT p.user_id, COUNT(l.photo_id) AS total_likes
    FROM photos p
    JOIN likes l ON l.photo_id = p.id
    GROUP BY p.user_id
) l ON l.user_id = u.id
LEFT JOIN (
    SELECT p.user_id, COUNT(c.id) AS total_comments
    FROM photos p
    JOIN comments c ON c.photo_id = p.id
    GROUP BY p.user_id
) c ON c.user_id = u.id
ORDER BY total_engagement DESC
LIMIT 10;


/* -----------------------------------------------------------
   Q5. Which user(s) have the highest number of
       followers and followings?
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COALESCE(f1.followers_count, 0) AS followers_count,
    COALESCE(f2.following_count, 0) AS following_count
FROM users u
LEFT JOIN (
    SELECT followee_id, COUNT(*) AS followers_count
    FROM follows
    GROUP BY followee_id
) f1 ON f1.followee_id = u.id
LEFT JOIN (
    SELECT follower_id, COUNT(*) AS following_count
    FROM follows
    GROUP BY follower_id
) f2 ON f2.follower_id = u.id
ORDER BY followers_count DESC
LIMIT 10;


/* -----------------------------------------------------------
   Q6. Calculate the average engagement rate (likes,
       comments) per post for each user.
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COALESCE(l.total_likes, 0) AS total_likes_received,
    COALESCE(c.total_comments, 0) AS total_comments_received,
    ROUND(COALESCE(l.total_likes, 0) * 1.0 / NULLIF(COUNT(DISTINCT p.id), 0), 2) AS avg_likes_per_post,
    ROUND(COALESCE(c.total_comments, 0) * 1.0 / NULLIF(COUNT(DISTINCT p.id), 0), 2) AS avg_comments_per_post,
    ROUND((COALESCE(l.total_likes, 0) + COALESCE(c.total_comments, 0)) * 1.0
          / NULLIF(COUNT(DISTINCT p.id), 0), 2) AS avg_engagement_per_post
FROM users u
LEFT JOIN photos p ON p.user_id = u.id
LEFT JOIN (
    SELECT p.user_id, COUNT(l.photo_id) AS total_likes
    FROM photos p JOIN likes l ON l.photo_id = p.id
    GROUP BY p.user_id
) l ON l.user_id = u.id
LEFT JOIN (
    SELECT p.user_id, COUNT(c.id) AS total_comments
    FROM photos p JOIN comments c ON c.photo_id = p.id
    GROUP BY p.user_id
) c ON c.user_id = u.id
GROUP BY u.id, u.username, l.total_likes, c.total_comments
ORDER BY avg_engagement_per_post DESC;


/* -----------------------------------------------------------
   Q7. Get the list of users who have never liked any post
       (users and likes tables)
   ----------------------------------------------------------- */

SELECT u.id, u.username
FROM users u
WHERE NOT EXISTS (
    SELECT 1 FROM likes l WHERE l.user_id = u.id
);


/* ============================================================
   SUBJECTIVE QUESTIONS
   ============================================================ */

/* -----------------------------------------------------------
   Q8. How can you leverage user-generated content (posts,
       hashtags, photo tags) to create more personalized and
       engaging ad campaigns?
   ----------------------------------------------------------- */

-- Build a per-user interest profile from the tags they post with
SELECT
    u.id,
    u.username,
    t.tag_name,
    COUNT(*) AS tag_frequency
FROM users u
JOIN photos p ON p.user_id = u.id
JOIN photo_tags pt ON pt.photo_id = p.id
JOIN tags t ON t.id = pt.tag_id
GROUP BY u.id, u.username, t.tag_name
ORDER BY u.id, tag_frequency DESC;

-- Platform-wide trending tags (helps prioritize ad categories)
SELECT
    t.tag_name,
    COUNT(*) AS usage_count
FROM photo_tags pt
JOIN tags t ON t.id = pt.tag_id
GROUP BY t.tag_name
ORDER BY usage_count DESC;


/* -----------------------------------------------------------
   Q9. Are there any correlations between user activity levels
       and specific content types (tags/topics)? How can this
       guide content creation and curation strategies?
   ----------------------------------------------------------- */

SELECT
    activity_tier,
    t.tag_name,
    COUNT(*) AS tag_usage
FROM (
    SELECT
        u.id,
        CASE
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) = 0 THEN 'Inactive'
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) BETWEEN 1 AND 20 THEN 'Low'
            WHEN COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) BETWEEN 21 AND 100 THEN 'Medium'
            ELSE 'High'
        END AS activity_tier
    FROM users u
    LEFT JOIN (SELECT user_id, COUNT(*) AS posts_count    FROM photos   GROUP BY user_id) p ON p.user_id = u.id
    LEFT JOIN (SELECT user_id, COUNT(*) AS likes_count    FROM likes    GROUP BY user_id) l ON l.user_id = u.id
    LEFT JOIN (SELECT user_id, COUNT(*) AS comments_count FROM comments GROUP BY user_id) c ON c.user_id = u.id
) ua
JOIN photos p ON p.user_id = ua.id
JOIN photo_tags pt ON pt.photo_id = p.id
JOIN tags t ON t.id = pt.tag_id
GROUP BY activity_tier, t.tag_name
ORDER BY activity_tier, tag_usage DESC;


/* -----------------------------------------------------------
   Q10. Which hashtags or content topics have the highest
        engagement rates? How can this guide content strategy
        and ad campaigns?
   ----------------------------------------------------------- */

SELECT
    t.tag_name,
    COUNT(DISTINCT pt.photo_id) AS posts_with_tag,
    COALESCE(SUM(l.like_count), 0) AS total_likes,
    COALESCE(SUM(c.comment_count), 0) AS total_comments,
    ROUND((COALESCE(SUM(l.like_count),0) + COALESCE(SUM(c.comment_count),0)) * 1.0
          / COUNT(DISTINCT pt.photo_id), 2) AS avg_engagement_per_post
FROM tags t
JOIN photo_tags pt ON pt.tag_id = t.id
LEFT JOIN (SELECT photo_id, COUNT(*) AS like_count FROM likes GROUP BY photo_id) l ON l.photo_id = pt.photo_id
LEFT JOIN (SELECT photo_id, COUNT(*) AS comment_count FROM comments GROUP BY photo_id) c ON c.photo_id = pt.photo_id
GROUP BY t.tag_name
ORDER BY avg_engagement_per_post DESC;


/* -----------------------------------------------------------
   Q11. For inactive users, what strategies would you
        recommend to re-engage them and encourage them to
        start posting or engaging again?
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    u.created_at AS joined_date,
    COALESCE(f.following_count, 0) AS following_count,
    COALESCE(fr.followers_count, 0) AS followers_count
FROM users u
LEFT JOIN (SELECT user_id, COUNT(*) AS posts_count    FROM photos   GROUP BY user_id) p ON p.user_id = u.id
LEFT JOIN (SELECT user_id, COUNT(*) AS likes_count    FROM likes    GROUP BY user_id) l ON l.user_id = u.id
LEFT JOIN (SELECT user_id, COUNT(*) AS comments_count FROM comments GROUP BY user_id) c ON c.user_id = u.id
LEFT JOIN (SELECT follower_id, COUNT(*) AS following_count FROM follows GROUP BY follower_id) f  ON f.follower_id  = u.id
LEFT JOIN (SELECT followee_id, COUNT(*) AS followers_count FROM follows GROUP BY followee_id) fr ON fr.followee_id = u.id
WHERE COALESCE(p.posts_count,0) + COALESCE(l.likes_count,0) + COALESCE(c.comments_count,0) = 0
ORDER BY followers_count DESC;


/* -----------------------------------------------------------
   Q12. Based on follower counts and engagement rates, which
        users would be ideal candidates for influencer
        marketing campaigns?
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COALESCE(fr.followers_count, 0) AS followers_count,
    COUNT(DISTINCT p.id) AS total_posts,
    COALESCE(l.total_likes, 0) AS total_likes_received,
    COALESCE(c.total_comments, 0) AS total_comments_received,
    ROUND((COALESCE(l.total_likes,0) + COALESCE(c.total_comments,0)) * 1.0
          / NULLIF(COUNT(DISTINCT p.id), 0), 2) AS avg_engagement_per_post
FROM users u
LEFT JOIN (SELECT followee_id, COUNT(*) AS followers_count FROM follows GROUP BY followee_id) fr ON fr.followee_id = u.id
LEFT JOIN photos p ON p.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(l.photo_id) AS total_likes FROM photos p JOIN likes l ON l.photo_id = p.id GROUP BY p.user_id) l ON l.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(c.id) AS total_comments FROM photos p JOIN comments c ON c.photo_id = p.id GROUP BY p.user_id) c ON c.user_id = u.id
WHERE COALESCE(fr.followers_count, 0) > 0
GROUP BY u.id, u.username, fr.followers_count, l.total_likes, c.total_comments
HAVING COUNT(DISTINCT p.id) > 0
ORDER BY followers_count DESC, avg_engagement_per_post DESC
LIMIT 10;


/* -----------------------------------------------------------
   Q13. Based on user behavior and engagement data, how would
        you segment the user base for targeted marketing
        campaigns or personalized recommendations?
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COALESCE(fr.followers_count, 0) AS followers_count,
    COUNT(DISTINCT p.id) AS total_posts,
    COALESCE(l.total_likes, 0) AS likes_received,
    COALESCE(c.total_comments, 0) AS comments_received,
    CASE
        WHEN COUNT(DISTINCT p.id) = 0 AND COALESCE(fr.followers_count,0) > 50 THEN 'Dormant Influencer'
        WHEN COUNT(DISTINCT p.id) = 0 THEN 'Fully Inactive'
        WHEN COUNT(DISTINCT p.id) > 0
             AND (COALESCE(l.total_likes,0)+COALESCE(c.total_comments,0)) * 1.0 / COUNT(DISTINCT p.id) >= 60
             AND COALESCE(fr.followers_count,0) >= 50 THEN 'High-Value Influencer'
        WHEN COUNT(DISTINCT p.id) > 5 THEN 'Active Creator'
        ELSE 'Casual Poster'
    END AS user_segment
FROM users u
LEFT JOIN (SELECT followee_id, COUNT(*) AS followers_count FROM follows GROUP BY followee_id) fr ON fr.followee_id = u.id
LEFT JOIN photos p ON p.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(l.photo_id) AS total_likes FROM photos p JOIN likes l ON l.photo_id = p.id GROUP BY p.user_id) l ON l.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(c.id) AS total_comments FROM photos p JOIN comments c ON c.photo_id = p.id GROUP BY p.user_id) c ON c.user_id = u.id
GROUP BY u.id, u.username, fr.followers_count, l.total_likes, c.total_comments
ORDER BY user_segment;


/* -----------------------------------------------------------
   Q14. If data on ad campaigns (impressions, clicks,
        conversions) is available, how would you measure
        their effectiveness and optimize future campaigns?
   ----------------------------------------------------------- */

-- NOTE: ad_campaigns / ad_events tables do NOT exist in ig_clone.
-- Below is the query structure IF such tables existed (hypothetical):
/*
CREATE TABLE ad_campaigns (
    id INT PRIMARY KEY,
    campaign_name VARCHAR(255),
    target_tag_id INT,
    start_date DATE,
    end_date DATE
);

CREATE TABLE ad_events (
    id INT PRIMARY KEY,
    campaign_id INT,
    user_id INT,
    event_type ENUM('impression','click','conversion'),
    event_time TIMESTAMP
);

SELECT
    c.campaign_name,
    COUNT(CASE WHEN e.event_type = 'impression' THEN 1 END) AS impressions,
    COUNT(CASE WHEN e.event_type = 'click' THEN 1 END) AS clicks,
    COUNT(CASE WHEN e.event_type = 'conversion' THEN 1 END) AS conversions,
    ROUND(COUNT(CASE WHEN e.event_type = 'click' THEN 1 END) * 100.0
          / NULLIF(COUNT(CASE WHEN e.event_type = 'impression' THEN 1 END), 0), 2) AS ctr_percent,
    ROUND(COUNT(CASE WHEN e.event_type = 'conversion' THEN 1 END) * 100.0
          / NULLIF(COUNT(CASE WHEN e.event_type = 'click' THEN 1 END), 0), 2) AS conversion_rate_percent
FROM ad_campaigns c
JOIN ad_events e ON e.campaign_id = c.id
GROUP BY c.campaign_name
ORDER BY conversion_rate_percent DESC;
*/

-- RUNNABLE substitute using existing tables: tags = "campaigns",
-- likes = "clicks" proxy, comments = "conversions" proxy
SELECT
    t.tag_name AS campaign_proxy,
    COUNT(DISTINCT pt.photo_id) AS posts_count,
    COALESCE(SUM(l.like_count), 0) AS total_clicks_proxy,
    COALESCE(SUM(c.comment_count), 0) AS total_conversions_proxy,
    ROUND(COALESCE(SUM(c.comment_count),0) * 100.0
          / NULLIF(SUM(l.like_count), 0), 2) AS conversion_rate_percent
FROM tags t
JOIN photo_tags pt ON pt.tag_id = t.id
LEFT JOIN (SELECT photo_id, COUNT(*) AS like_count FROM likes GROUP BY photo_id) l ON l.photo_id = pt.photo_id
LEFT JOIN (SELECT photo_id, COUNT(*) AS comment_count FROM comments GROUP BY photo_id) c ON c.photo_id = pt.photo_id
GROUP BY t.tag_name
ORDER BY conversion_rate_percent DESC;


/* -----------------------------------------------------------
   Q15. How can you use user activity data to identify
        potential brand ambassadors or advocates who could
        help promote Instagram's initiatives or events?
   ----------------------------------------------------------- */

SELECT
    u.id,
    u.username,
    COALESCE(fr.followers_count, 0) AS followers_count,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT cm.id) AS comments_given,
    COUNT(DISTINCT lk.photo_id) AS likes_given,
    COALESCE(l.total_likes_received, 0) AS likes_received,
    COALESCE(c.total_comments_received, 0) AS comments_received,
    ROUND((COALESCE(l.total_likes_received,0) + COALESCE(c.total_comments_received,0)) * 1.0
          / NULLIF(COUNT(DISTINCT p.id), 0), 2) AS avg_engagement_per_post
FROM users u
LEFT JOIN (SELECT followee_id, COUNT(*) AS followers_count FROM follows GROUP BY followee_id) fr ON fr.followee_id = u.id
LEFT JOIN photos p ON p.user_id = u.id
LEFT JOIN comments cm ON cm.user_id = u.id
LEFT JOIN likes lk ON lk.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(l.photo_id) AS total_likes_received FROM photos p JOIN likes l ON l.photo_id = p.id GROUP BY p.user_id) l ON l.user_id = u.id
LEFT JOIN (SELECT p.user_id, COUNT(c.id) AS total_comments_received FROM photos p JOIN comments c ON c.photo_id = p.id GROUP BY p.user_id) c ON c.user_id = u.id
GROUP BY u.id, u.username, fr.followers_count, l.total_likes_received, c.total_comments_received
HAVING COUNT(DISTINCT p.id) >= 5              -- consistent poster
   AND COUNT(DISTINCT cm.id) >= 10             -- active community participant
   AND COALESCE(fr.followers_count,0) >= 50    -- has real reach
ORDER BY avg_engagement_per_post DESC, followers_count DESC
LIMIT 15;


/* -----------------------------------------------------------
   Q16. How would you approach this problem, if the objective
        and subjective questions weren't given?
   ----------------------------------------------------------- */

-- First step of any undirected analysis: profile every table's scale
SELECT 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION ALL
SELECT 'photos', COUNT(*) FROM photos
UNION ALL
SELECT 'comments', COUNT(*) FROM comments
UNION ALL
SELECT 'likes', COUNT(*) FROM likes
UNION ALL
SELECT 'follows', COUNT(*) FROM follows
UNION ALL
SELECT 'tags', COUNT(*) FROM tags
UNION ALL
SELECT 'photo_tags', COUNT(*) FROM photo_tags;


/* -----------------------------------------------------------
   Q17. Assuming there's a "User_Interactions" table tracking
        user engagements, how can you update the
        "Engagement_Type" column to change all instances of
        "Like" to "Heart"?
   ----------------------------------------------------------- */

-- Recommended: preview before updating
SELECT * FROM User_Interactions WHERE Engagement_Type = 'Like';
SELECT COUNT(*) FROM User_Interactions WHERE Engagement_Type = 'Like';

-- The actual update
UPDATE User_Interactions
SET Engagement_Type = 'Heart'
WHERE Engagement_Type = 'Like';

/* ============================================================
   END OF FILE
   ============================================================ */